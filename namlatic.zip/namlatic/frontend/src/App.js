import React from "react";
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Events from './Events';
import Booking from './Booking';
//import axios from 'axios';
//import "./app.css";
class App extends React.Component {

constructor(props)
{

  super(props);
  this.state = {


  };
}





  render() {
    return (
      <Router>
<div>

<Switch>
              <Route exact path='/' component={Events} />
              <Route path='/booking/:id' component={Booking} />

          </Switch>
    </div>
    </Router>
  );



  }
}

export default App;
