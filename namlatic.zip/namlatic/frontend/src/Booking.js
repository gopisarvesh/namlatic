import React,{Component} from 'react';
import axios from 'axios';
import { browserHistory,Link } from 'react-router-dom';

class Booking extends Component {

  constructor(props){
    super(props);
    this.state={
      name:'',
      email:'',
      phoneno:'',
      noofseats:'',
      noofattends:'',
      image:'',
      eventid:'',
      totalseats:'',
      eventname:'',




    }
  }

seatsupdate=()=>{
console.log(this.state);
  axios({
      method: 'put',
      url: 'http://localhost:8080/bookingupdate',
      data: this.state,
      headers: {'Content-Type': 'application/json' }
      })
      .then(function (response) {
          //handle success
          //alert(response.status);
          //browserHistory.push('/');
          this.props.history.push("/");

          if(response.status===200){
          //  this.loaddata();
          //this.props.history.push("/");

            //alert("Created Successfuly");
          }
        //  console.log(response);
      }.bind(this))
      .catch(function (response) {
          //handle error
          console.log(response);
      });


}


handlesubmit=(event)=>{
event.preventDefault();

//alert(this.state.noofseats);
//alert(this.state.totalseats);
if(parseInt(this.state.noofseats)>parseInt(this.state.totalseats)){
  alert("Please enter the valid no of seats value");
  return false;
}

if(parseInt(this.state.noofattends)>parseInt(this.state.noofseats)){
  alert("Please enter the valid Attendee value");
  return false;
}


axios({
    method: 'post',
    url: 'http://localhost:8080/bookingcreate',
    data: this.state,
    headers: {'Content-Type': 'application/json' }
    })
    .then(function (response) {
        //handle success
        alert(response.status);
        if(response.status===200){
          this.seatsupdate();
          alert("Created Successfuly");
        }
      //  console.log(response);
    }.bind(this))



}


  loaddata=()=>{

    //this.props.location.state.detail
//console.log(this.props.history);
var mainstr=this.props.history.location.pathname;
var replacedid=mainstr.replace("/booking/","");
console.log(replacedid);

axios.post('http://localhost:8080/eventdetailsbyid', {
    eventid: replacedid,
  })
  .then(function (response) {
    console.log(response['data']['msg']);

    if(response){

      this.setState({
image:response['data']['msg'][0]['image'],
totalseats:response['data']['msg'][0]['availableseats'],
eventname:response['data']['msg'][0]['name'],
eventid:replacedid

      })
    }


  }.bind(this))

}


handleChange=(event)=>{

if(event.target.name==='name') {
this.setState({
  name:event.target.value
})
}

if(event.target.name==='email') {
this.setState({
  email:event.target.value
})
}

if(event.target.name==='phoneno') {
this.setState({
  phoneno:event.target.value
})
}

if(event.target.name==='noofseats') {
this.setState({
  noofseats:event.target.value
})


}

if(event.target.name==='noofattends') {
this.setState({
  noofattends:event.target.value
})
}

}

componentDidMount(){
//console.log(this.props.history.location.pathname);


this.loaddata();
}

render(){
  return (
    <div className="App">
<div class="container">



    <h3>{this.state.eventname}</h3>

    <h5>No of available seats: {this.state.totalseats}</h5>
    <form onSubmit={this.handlesubmit}>
    <div class="row">

<div class="col-md-4">
<img src={this.state.image} />
</div>

<div class="col-md-8">
<div class="row">
<div class="col-md-6" style={{textAlign:"right"}}>Name</div>
<div class="col-md-6"><input required type="text" onChange={this.handleChange} name="name" id="name" class="form-control" />
</div>
</div>


<br />
<div class="row">
<div class="col-md-6" style={{textAlign:"right"}}>Email</div>
<div class="col-md-6"><input required type="email" onChange={this.handleChange} name="email" id="email" class="form-control" />
</div>
</div>

<br />
<div class="row">
<div class="col-md-6" style={{textAlign:"right"}}>Phone No</div>
<div class="col-md-6"><input required type="text" onChange={this.handleChange} name="phoneno" id="phoneno" class="form-control" />
</div>
</div>

<br />
<div class="row">
<div class="col-md-6" style={{textAlign:"right"}}>No of Seats</div>
<div class="col-md-6"><input required type="text" onChange={this.handleChange} name="noofseats" id="noofseats" class="form-control" />
</div>
</div>
<br />
<div class="row">
<div class="col-md-6" style={{textAlign:"right"}}>No of Attendee</div>
<div class="col-md-6"><input required type="text" onChange={this.handleChange} name="noofattends" id="noofattends" class="form-control" />
</div>


</div>

</div>



  </div>


  <div class="row">
  <div class="col-md-12">
<input type="submit" name="submit" id="submit" value="Submit" class="btn btn-primary" />
&nbsp;&nbsp;
<Link to='/' ><input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-danger" /></Link>
  </div>
  </div>
  </form>
</div>
    </div>
  );
}
}

export default Booking;
