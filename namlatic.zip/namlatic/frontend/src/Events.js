import React,{Component} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';


class Events extends Component {

  constructor(props){
    super(props);
    this.state={
      totalrecords:[],

    }
  }

  loaddata=()=>{
  axios.get("http://localhost:8080/eventdetails").then(function(result){

    //console.log(result['data']['msg']);
    var totalres=result['data']['msg'];
  //  console.log(totalres);
    if(result['data']['msg']!==null){
    this.setState({totalrecords:totalres});
  }
}.bind(this))

}
handleChange=(event)=>{
  //alert(event.target.value);




  axios.post('http://localhost:8080/eventdetailsbyfilter', {
      eventname: event.target.value,
    })
    .then(function (response) {
      console.log(response['data']['msg']);
      var totalres=response['data']['msg'];
    //  console.log(totalres);
      if(response['data']['msg']!==null){
      this.setState({totalrecords:totalres});
    }


    }.bind(this))

}

componentDidMount(){

this.loaddata();
}

render(){
  return (
    <div className="App">
<div class="container">

    <h3>List of Events</h3>
    <br />
  <div class="row"><div class="col-md-8">
    <input type="text" class="form-control" name="searchevents" onChange={this.handleChange} id="searchevents" placeholder="Search Events" />

</div>

</div>

<br />
        <div class="row">

{
this.state.totalrecords.map(record=>(


    <div class="card" style={{width: "20rem"}}>
      <div class="card-body">
      <h4>{record.name}</h4>

<div style={{float:"left"}} class="col-md-5">
<img class="card-img-top" style={{height:"100px"}} src={record.image} alt="Card image cap"/>
</div>

<div style={{float:"left"}} class="col-md-7">
{record.datetime} <br />
Seats Available:{record.availableseats} <br />
<Link to={'/booking/'+record._id }  ><input type="button" name="booknow" value="Booknow" class="btn btn-primary" /></Link>
</div>

</div>

      </div>


))
  }
  </div>
</div>
    </div>
  );
}
}

export default Events;
