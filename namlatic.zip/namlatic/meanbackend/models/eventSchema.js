var mongoose = require('mongoose');

var eventSchema = mongoose.Schema({
   name: {
    type: String

  },
  availableseats: {
    type: String
  },
  image: {
    type: String
  },
  datetime: {
    type: String
  },

});

module.exports = mongoose.model('events', eventSchema);
