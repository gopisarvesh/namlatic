var mongoose = require('mongoose');

var bookingSchema = mongoose.Schema({
   name: {
    type: String

  },
  email: {
    type: String
  },
  phoneno: {
    type: String
  },
  noofseats: {
    type: String
  },

  noofattends: {
    type: String
  },

  eventid: {
    type: String
  },

  created_datetime: {
    type:  Date,default:new Date()
  },
status: {
type: Number, default: 1
}

});

module.exports = mongoose.model('booking', bookingSchema);
