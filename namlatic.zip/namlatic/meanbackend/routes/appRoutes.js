var express=require('express');
var router=express.Router();

var Booking=require('../models/bookingSchema');
var Event=require('../models/eventSchema');



var ObjectId = require('mongodb').ObjectID;




router.post('/eventdetailsbyfilter',(req,res)=>{


var eventname=req.body.eventname;
//console.log(eventname);
if(eventname!=""){
  Event.find({name:eventname},(err,result)=>{


    //console.log(result)
    if(err)
    res.status(500).json({errmsg:err});
    res.status(200).json({msg:result});
})

} else {

  Event.find((err,result)=>{


    //console.log(result)
    if(err)
    res.status(500).json({errmsg:err});
    res.status(200).json({msg:result});
  })

}
});



router.get('/eventdetails',(req,res)=>{




  Event.find((err,result)=>{
    //console.log(result)
    if(err)
    res.status(500).json({errmsg:err});
    res.status(200).json({msg:result});
})
});

router.post('/eventdetailsbyid',(req,res)=>{

var id=req.body.eventid;
  Event.find({_id:id},(err,result)=>{
    //console.log(result)
    if(err)
    res.status(500).json({errmsg:err});
    res.status(200).json({msg:result});
  })
  });



  router.put('/bookingupdate',(req,res,next)=>{


  var reducedseat=parseInt(req.body.totalseats)-parseInt(req.body.noofseats);
  console.log(reducedseat);
  console.log(req.body.eventid);
  Event.findById(req.body.eventid,(err,booking)=>{

  //if(err)
  //res.status(500).json({errmsg:err});
  booking.availableseats=reducedseat;
  booking.save((err,res)=>{
  //if(err)
  //res.status(500).json({errmsg:err});
  //res.status(200).json({msg:res});


  });



  });

  });



router.post('/bookingcreate',(req,res)=>{

  var newBooking=new Booking({

  name:req.body.name,
  email:req.body.email,
  phoneno:req.body.phoneno,
  noofseats:req.body.noofseats,
  noofattends:req.body.noofattends,
  eventid:req.body.eventid,


  });

  newBooking.save((err,results)=>{

  if(err)
  res.status(500).json({errmsg:err});
  res.status(200).json({msg:results});
  });




})












module.exports=router;
